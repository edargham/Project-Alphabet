/*
-- Query: 
-- Date: 2017-07-20 12:20
*/
INSERT INTO `Role` (`idRole`,`Role_Name`,`Role_Code`) VALUES (1,'Coordinator','ADMIN');
INSERT INTO `Role` (`idRole`,`Role_Name`,`Role_Code`) VALUES (2,'Teacher','MANAGER');
INSERT INTO `Role` (`idRole`,`Role_Name`,`Role_Code`) VALUES (3,'Student','USER');
