/*
-- Query: 
-- Date: 2017-07-20 12:40
*/
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (1,'Basic Technology Skill',NULL,NULL,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (2,'Operating Systems: Microsoft Windows ',NULL,NULL,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (3,'Email Communication',NULL,NULL,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (4,'Keyboarding: Typing.com','Typing Lessons: Focus on typing accuracy, proper finger placment, not speed. Speed will be acquired naturally over time in the future months and years of typing lessons.',NULL,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (5,'Microsoft Powerpoint',NULL,NULL,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (6,'Microsoft Excel: The Basics',NULL,NULL,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (7,'Hardware',NULL,1,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (8,'Mouse Discovery',NULL,1,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (9,'Keyboard Discovery',NULL,1,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (10,'Screen',NULL,1,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (11,'Central Processing Unit',NULL,1,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (12,'Desktop',NULL,2,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (13,'Mail',NULL,3,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (14,'Address Book',NULL,3,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (15,'Settings',NULL,3,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (16,'Composing',NULL,13,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (17,'Replying',NULL,13,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (18,'Contacts',NULL,14,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (19,'Identities',NULL,15,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (20,'Typing position: Technique and Posture',NULL,4,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (21,'The Home Row',NULL,4,'07/06/2017',2,2);
INSERT INTO `Skill` (`idSkill`,`Skill_Name`,`Skill_Description`,`Parent_Skill_ID`,`Date_Created`,`Person_idPerson`,`Rating_idRating`) VALUES (22,'Practicing Typing for Beginners',NULL,4,'07/06/2017',2,2);
