/*
-- Query: 
-- Date: 2017-07-20 12:28
*/
INSERT INTO `Person` (`idPerson`,`Username`,`First_Name`,`Last_Name`,`Parent_Person_ID`,`Group_idGroup`,`Role_idRole`,`Rating_idRating`) VALUES (1,'cs_coordinator','Computer Science','Coordinator',NULL,11,1,100);
INSERT INTO `Person` (`idPerson`,`Username`,`First_Name`,`Last_Name`,`Parent_Person_ID`,`Group_idGroup`,`Role_idRole`,`Rating_idRating`) VALUES (2,'cs_teacher01','Computer Science','Teacher1',1,11,2,100);
INSERT INTO `Person` (`idPerson`,`Username`,`First_Name`,`Last_Name`,`Parent_Person_ID`,`Group_idGroup`,`Role_idRole`,`Rating_idRating`) VALUES (3,'cs_teacher02','Computer Science','Teacher2',1,11,2,100);
INSERT INTO `Person` (`idPerson`,`Username`,`First_Name`,`Last_Name`,`Parent_Person_ID`,`Group_idGroup`,`Role_idRole`,`Rating_idRating`) VALUES (4,'cs_student01','Computer Science','Student1',2,7,3,7);
INSERT INTO `Person` (`idPerson`,`Username`,`First_Name`,`Last_Name`,`Parent_Person_ID`,`Group_idGroup`,`Role_idRole`,`Rating_idRating`) VALUES (5,'cs_student02','Computer Science','Student2',2,7,3,7);
INSERT INTO `Person` (`idPerson`,`Username`,`First_Name`,`Last_Name`,`Parent_Person_ID`,`Group_idGroup`,`Role_idRole`,`Rating_idRating`) VALUES (6,'cs_student03','Computer Science','Student3',3,5,3,5);
INSERT INTO `Person` (`idPerson`,`Username`,`First_Name`,`Last_Name`,`Parent_Person_ID`,`Group_idGroup`,`Role_idRole`,`Rating_idRating`) VALUES (7,'cs_student04','Computer Science','Student4',3,5,3,5);
