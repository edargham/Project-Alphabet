/*
-- Query: 
-- Date: 2017-07-20 12:22
*/
INSERT INTO `Group` (`idGroup`,`Group_Name`,`Rating_idRating`) VALUES (1,'Grade 1A',1);
INSERT INTO `Group` (`idGroup`,`Group_Name`,`Rating_idRating`) VALUES (2,'Grade 1B',1);
INSERT INTO `Group` (`idGroup`,`Group_Name`,`Rating_idRating`) VALUES (3,'Grade 3',3);
INSERT INTO `Group` (`idGroup`,`Group_Name`,`Rating_idRating`) VALUES (4,'Grade 4',4);
INSERT INTO `Group` (`idGroup`,`Group_Name`,`Rating_idRating`) VALUES (5,'Grade 5',5);
INSERT INTO `Group` (`idGroup`,`Group_Name`,`Rating_idRating`) VALUES (6,'Grade 6',6);
INSERT INTO `Group` (`idGroup`,`Group_Name`,`Rating_idRating`) VALUES (7,'Grade 7',7);
INSERT INTO `Group` (`idGroup`,`Group_Name`,`Rating_idRating`) VALUES (8,'Grade 8',8);
INSERT INTO `Group` (`idGroup`,`Group_Name`,`Rating_idRating`) VALUES (9,'Grade 9',9);
INSERT INTO `Group` (`idGroup`,`Group_Name`,`Rating_idRating`) VALUES (10,'Grade 10',10);
INSERT INTO `Group` (`idGroup`,`Group_Name`,`Rating_idRating`) VALUES (11,'Grade 11',11);
INSERT INTO `Group` (`idGroup`,`Group_Name`,`Rating_idRating`) VALUES (12,'Grade 12',12);
INSERT INTO `Group` (`idGroup`,`Group_Name`,`Rating_idRating`) VALUES (NULL,'Grade 2',2);
