/*
-- Query: 
-- Date: 2017-07-06 09:57
*/
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (1,'Basic Technology Skill',NULL,NULL,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (2,'Operating Systems: Microsoft Windows ',NULL,NULL,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (3,'Email Communication',NULL,NULL,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (4,'Keyboarding: Typing.com','Typing Lessons: Focus on typing accuracy, proper finger placment, not speed. Speed will be acquired naturally over time in the future months and years of typing lessons.',NULL,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (5,'Microsoft Powerpoint',NULL,NULL,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (6,'Microsoft Excel: The Basics',NULL,NULL,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (7,'Hardware',NULL,1,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (8,'Mouse Discovery',NULL,1,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (9,'Keyboard Discovery',NULL,1,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (10,'Screen',NULL,1,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (11,'Central Processing Unit',NULL,1,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (12,'Desktop',NULL,2,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (13,'Mail',NULL,3,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (14,'Address Book',NULL,3,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (15,'Settings',NULL,3,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (16,'Composing',NULL,13,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (17,'Replying',NULL,13,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (18,'Contacts',NULL,14,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (19,'Identities',NULL,15,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (20,'Typing position: Technique and Posture',NULL,4,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (21,'The Home Row',NULL,4,1,'07/06/2017');
INSERT INTO `Category` (`idCategory`,`Category_Name`,`Description`,`Parent_Category_ID`,`CreatorID`,`Date_Created`) VALUES (22,'Practicing Typing for Beginners',NULL,4,1,'07/06/2017');
